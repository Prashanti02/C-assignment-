#include <iostream>
#include <iomanip>
#include <fstream> 
#include <string>
#include <vector>
#include <algorithm>

using namespace std; 

void mostfreq(ifstream &story)
{
    vector <string> words;
    string ch;
    
    while(story)
    {
        story>>ch;
        words.push_back(ch);
    }
    
    int size=words.size();
    
    sort(words.begin(), words.end());
    
    string temp= words[0];
    int n=1;
    int freq=0;
    string freqword;
    
    int ten[10];
    int t=0;
    int repeated=size;
    
    string tenWords[10];
    
    while(t<10){
        for (int i=1; i<size; i++)
        {
            if (temp==words[i])
            {
                temp=words[i];
                n++;
            }
            else if (temp != words[i] && n<repeat)
            {
                if(most<n)
                {
                    most=n;
                    freqword=temp;
                }
                n=0;
                temp=words[i];
            }
            else
            {
                temp=words[i];
                n=0;
            }
        }
        repeat=most;
        ten[t]=most;
        
        tenWords[t]= mostfreq;
        
        most=0;
        t++;
    }
    cout<<endl;
    
    for (int i=0; i<10; i++)
    {
        cout<<(i+1)<<"="<<ten[i]<< " word = "<<tenWords[i]<<endl;
    }
}

int main(){
    ifstream story;
    story.open("pandp11.txt");
    freq(story);

    }
            }
            }
        }
    }
}
